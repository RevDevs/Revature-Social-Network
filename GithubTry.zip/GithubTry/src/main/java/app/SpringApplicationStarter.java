package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.social.github.api.GistOperations;
import org.springframework.social.github.api.GitHub;
import org.springframework.social.github.api.GitHubUser;
import org.springframework.social.github.api.GitHubUserProfile;
import org.springframework.social.github.api.UserOperations;
import org.springframework.social.github.api.impl.GitHubTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@RestController
@PropertySource("classpath:loginauth.properties")
@SpringBootApplication
public class SpringApplicationStarter {
	@Autowired
	Environment env;

	public static void main(String[] args) {
		SpringApplication.run(SpringApplicationStarter.class, args);
	}

	@RequestMapping("/")
	public String index() {
		return "Hello from Spring Boot!";
	}

	@RequestMapping("/login")
	public String loginPage() {
		return "/githubTry.html";
	}

	//https://developer.github.com/apps/building-integrations/setting-up-and-registering-oauth-apps/about-authorization-options-for-oauth-apps/

	//get("http://github.com/login/oauth/authorize?scope=user:email&client_id=299abee678c45d347d13",);
	//parameters:
	//client_id, project id from github dev
	//redirect_uri, url to redirect to
	//state, "ungessable" string

	//scope, user/user:email scope we dont need anything else

	/*https://developer.github.com/apps/building-integrations/setting-up-and-registering-oauth-apps/about-authorization-options-for-oauth-apps/
	 * 
	 * https://tools.ietf.org/html/rfc6749#section-4.1
	 * the process
	 * 
	 * https://developer.github.com/v3/oauth_authorizations/#get-or-create-an-authorization-for-a-specific-app
	 * 
	 */
	/**
	 * need web flow
	 * https://docs.spring.io/autorepo/docs/webflow/2.4.1.RELEASE/reference/html/spring-mvc.html
	 * @param req
	 * @param res
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	@RequestMapping("/login/github")
	public String  loginGithub(HttpServletRequest req,HttpServletResponse res) throws ClientProtocolException, IOException {
		Enumeration<String> enums = req.getParameterNames();

		while(enums.hasMoreElements()){
			String s = enums.nextElement();
			System.out.println("string: "+s);
		}

		//			String cid = req.getParameter("client_id");
		//			String rURI = req.getParameter("redirect_uri");
		String c = req.getParameter("code");
		//			String st = req.getParameter("state");	
		//			String sc = req.getParameter("scope");

		//			System.out.println("redirect_uri "+rURI);
		//			System.out.println("client_id "+cid);
		System.out.println("code "+c);
		//			System.out.println("state "+st);
		//			System.out.println("scope "+sc);

		//Exchange this "code", temporary code parameter for an access token:

		//post "https://github.com/login/oauth/access_token" 
		//parameters:
		//Required client_id
		//Required client_secret
		//Required code, exchange for access token
		//redirect_uri, check for correct passed value
		//state, double check for authenticity 

		///response
		//accept header to application/json, so that we see it in readble info	

		String neededURL= "https://github.com/login/oauth/access_token";

		String clientId = env.getProperty("github.client_Id");// "299abee678c45d347d13";
		String clientSecret = env.getProperty("github.client_Secret");//"586251289a93a331da49d9557ce28d716e4acefe";
		String redirectU = "http://localhost:8080/login/github";

		System.out.println(clientId+", "+clientSecret);

		HttpUrl.Builder urlBuilder = HttpUrl.parse(neededURL).newBuilder();
		urlBuilder.addQueryParameter("client_id",clientId);
		urlBuilder.addQueryParameter("client_secret",clientSecret);
		urlBuilder.addQueryParameter("code",c);
		urlBuilder.addQueryParameter("redirect_uri",redirectU);

		String fullUrl = urlBuilder.build().toString();

		Request postRequest = new Request.Builder().url(fullUrl).build();

		OkHttpClient client = new OkHttpClient();
		Response response = client.newCall(postRequest).execute();

		//			System.out.println(response.body().string());
		String fullResponse = response.body().string();
		//			access_token=17a95c88d5d10ea77646386b6086a7b64cde9c5f&scope=user%3Aemail&token_type=bearer
		//seperate by & sign then by =

		String[] splitResponse = fullResponse.split("&");

//		for(String s: splitResponse) {
//			System.out.println(s);
//		}

		String[] splitToken = splitResponse[0].split("=");
		String[] splitScope = splitResponse[1].split("=");
		String[] splitType = splitResponse[2].split("=");

		String token = splitToken[1];
		String scope = splitScope[1];
		String type = splitType[1];

		System.out.println("Token: "+token);
		System.out.println("Scope: "+scope);
		System.out.println("Type: "+type);

		//		String accessToken = "asmfpafmas";
		GitHub github = new GitHubTemplate(token);
		UserOperations userOP = github.userOperations();
		GitHubUserProfile profile = userOP.getUserProfile();	
		System.out.println("Username: "+profile.getUsername());
		System.out.println("Name: "+profile.getName());
		System.out.println("Email: "+profile.getEmail());
		System.out.println("Location: "+profile.getLocation());
		System.out.println("Profile Id: "+userOP.getProfileId());
		System.out.println("Profile URL: "+userOP.getProfileUrl());
		/*	i can get more with teh userOperations: 
		https://docs.spring.io/autorepo/docs/spring-social-github/1.0.0.M4/api/org/springframework/social/github/api/UserOperations.html
		and same with user profile:
		https://docs.spring.io/autorepo/docs/spring-social-github/1.0.0.M4/api/org/springframework/social/github/api/GitHubUserProfile.html
		and user
		https://docs.spring.io/autorepo/docs/spring-social-github/1.0.0.M4/api/org/springframework/social/github/api/GitHubUser.html

		 */
		return "it worked";
		/*			HttpPost httpPost = new HttpPost();

			//http://www.baeldung.com/httpclient-post-http-request
//			CloseableHttpClient client = HttpClients.createDefault();

			HttpClient client = HttpClientBuilder.create().build();
			List<NameValuePair> params = new ArrayList<NameValuePair>();
			params.add(new BasicNameValuePair("client_id",clientId));
			params.add(new BasicNameValuePair("client_id",clientSecret));
			params.add(new BasicNameValuePair("code",c));
			params.add(new BasicNameValuePair("redirect_uri",redirectU));

			httpPost.setEntity(new UrlEncodedFormEntity(params));

			HttpResponse response = client.execute(httpPost);
			System.out.println("Response Code : "
			                + response.getStatusLine().getStatusCode());

			System.out.println("\n Starting read..");

			BufferedReader rd = new BufferedReader(
			        new InputStreamReader(response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}

			System.out.println("\n read done.. \n");
			System.out.println("result: "+result);*/


		//			res.setStatus(HttpServletResponse.SC_TEMPORARY_REDIRECT );
		//			res.setHeader("Location", neededURL);
		//			

		//			profile.toString();
		//			return "In progress";
	}

}